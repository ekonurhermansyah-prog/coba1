<?php require_once __DIR__.'/../config.php'; require_admin();

// Filtering params
$q = trim($_GET['q'] ?? '');
$origin = $_GET['origin'] ?? '';
$part = $_GET['part'] ?? '';
$from = $_GET['from'] ?? '';
$to   = $_GET['to'] ?? '';

$where = [];$params=[];
if($q){ $where[] =('(r.name LIKE ? OR r.email LIKE ? OR r.affiliation LIKE ? OR r.whatsapp LIKE ?)'); array_push($params, "%$q%","%$q%","%$q%","%$q%"); }
if($origin==='internal' || $origin==='external'){ $where[] =('r.origin = ?'); $params[] =($origin); }
if(in_array($part,['Seminar','Call for Paper','Keduanya'])){ $where[] =('r.participation = ?'); $params[] =($part); }
if($from){ $where[] =('date(r.created_at) >= date(?)'); $params[] =($from); }
if($to){ $where[] =('date(r.created_at) <= date(?)'); $params[] =($to); }

$sql = 'SELECT r.*, u.name AS account_name, u.email AS account_email FROM registrations r LEFT JOIN users u ON u.id=r.user_id';
if($where){ $sql .= ' WHERE ' . implode(' AND ', $where); }
$sql .= ' ORDER BY r.created_at DESC, r.id DESC';

// Export XLS (Excel-compatible)
if(isset($_GET['export']) && $_GET['export']==='xls'){
  header('Content-Type: application/vnd.ms-excel; charset=utf-8');
  header('Content-Disposition: attachment; filename="registrations-'.date('Ymd-His').'.xls"');
  echo "<table border='1'>";
  echo "<tr><th>ID</th><th>Tanggal</th><th>Nama</th><th>Email</th><th>WA</th><th>Institusi</th><th>Origin</th><th>Mengikuti</th><th>Akun (Nama)</th><th>Akun (Email)</th></tr>";
  $stmt = $pdo->prepare($sql); $stmt->execute($params);
  while($r = $stmt->fetch()){
    echo '<tr>';
    echo '<td>'.htmlspecialchars($r['id']).'</td>';
    echo '<td>'.htmlspecialchars($r['created_at']).'</td>';
    echo '<td>'.htmlspecialchars($r['name']).'</td>';
    echo '<td>'.htmlspecialchars($r['email']).'</td>';
    echo '<td>'.htmlspecialchars($r['whatsapp']).'</td>';
    echo '<td>'.htmlspecialchars($r['affiliation']).'</td>';
    echo '<td>'.htmlspecialchars($r['origin']).'</td>';
    echo '<td>'.htmlspecialchars($r['participation']).'</td>';
    echo '<td>'.htmlspecialchars($r['account_name']).'</td>';
    echo '<td>'.htmlspecialchars($r['account_email']).'</td>';
    echo '</tr>';
  }
  echo '</table>'; exit;
}

// Export CSV
if(isset($_GET['export']) && $_GET['export']==='csv'){
  header('Content-Type: text/csv; charset=utf-8');
  header('Content-Disposition: attachment; filename="registrations-'.date('Ymd-His').'.csv"');
  $out = fopen('php://output','w');
  fputcsv($out, ['ID','Tanggal','Nama','Email','WA','Institusi','Origin','Mengikuti','Akun (Nama)','Akun (Email)']);
  $stmt = $pdo->prepare($sql); $stmt->execute($params);
  while($r = $stmt->fetch()){
    fputcsv($out, [ $r['id'],$r['created_at'],$r['name'],$r['email'],$r['whatsapp'],$r['affiliation'],$r['origin'],$r['participation'],$r['account_name'],$r['account_email'] ]);
  }
  fclose($out); exit;
}

$stmt = $pdo->prepare($sql); $stmt->execute($params); $rows = $stmt->fetchAll();
?>
<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Registrasi Peserta</title><link rel="stylesheet" href="../assets/css/style.css"></head>
<body>
<?php include __DIR__ . '/../partials/admin_header.php'; ?>
<div class="container">
  <h2>Registrasi Peserta</h2>
  <form method="get" class="grid3" style="align-items:end">
    <div class="card"><div class="p">
      <label>Cari (nama/email/WA/institusi)</label>
      <input name="q" value="<?php echo e($q); ?>" placeholder="Ketik kata kunci">
    </div></div>
    <div class="card"><div class="p">
      <label>Origin</label>
      <select name="origin">
        <option value="">Semua</option>
        <option value="internal" <?php echo $origin==='internal'?'selected':''; ?>>Internal UNW</option>
        <option value="external" <?php echo $origin==='external'?'selected':''; ?>>External</option>
      </select>
      <label>Mengikuti</label>
      <select name="part">
        <option value="">Semua</option>
        <option <?php echo $part==='Seminar'?'selected':''; ?>>Seminar</option>
        <option <?php echo $part==='Call for Paper'?'selected':''; ?>>Call for Paper</option>
        <option <?php echo $part==='Keduanya'?'selected':''; ?>>Keduanya</option>
      </select>
    </div></div>
    <div class="card"><div class="p">
      <label>Dari Tanggal</label>
      <input type="date" name="from" value="<?php echo e($from); ?>">
      <label>Sampai</label>
      <input type="date" name="to" value="<?php echo e($to); ?>">
      <div style="margin-top:10px;display:flex;gap:8px">
        <button class="btn" type="submit">Terapkan Filter</button>
        <a class="btn secondary" href="?">Reset</a>
        <a class="btn" href="?<?php echo http_build_query(array_filter(['q'=>$q,'origin'=>$origin,'part'=>$part,'from'=>$from,'to'=>$to])); ?>&export=csv">Export CSV</a> <a class="btn secondary" href="?<?php echo http_build_query(array_filter(['q'=>$q,'origin'=>$origin,'part'=>$part,'from'=>$from,'to'=>$to])); ?>&export=xls">Export Excel</a>
      </div>
    </div></div>
  </form>

  <div class="card"><div class="p">
    <table class="table">
      <tr>
        <th>ID</th><th>Tanggal</th><th>Nama</th><th>Email</th><th>WA</th><th>Institusi</th><th>Origin</th><th>Mengikuti</th><th>Akun</th>
      </tr>
      <?php foreach($rows as $r): ?>
      <tr>
        <td><?php echo e($r['id']); ?></td>
        <td><?php echo e($r['created_at']); ?></td>
        <td><?php echo e($r['name']); ?></td>
        <td><?php echo e($r['email']); ?></td>
        <td><?php echo e($r['whatsapp']); ?></td>
        <td><?php echo e($r['affiliation']); ?></td>
        <td><?php echo $r['origin']==='internal'?'Internal UNW':($r['origin']==='external'?'External':'-'); ?></td>
        <td><?php echo e($r['participation']); ?></td>
        <td><?php echo e($r['account_name']); ?><br><small><?php echo e($r['account_email']); ?></small></td>
      </tr>
      <?php endforeach; ?>
    </table>
  </div></div>
</div>
<?php include __DIR__ . '/../partials/footer.php'; ?>
</body></html>
