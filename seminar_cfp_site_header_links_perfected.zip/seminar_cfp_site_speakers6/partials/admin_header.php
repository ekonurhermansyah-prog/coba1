<?php require_once __DIR__.'/../config.php'; require_admin();
// Compute site base path (strip trailing /admin from current script dir)
$baseCurrent = rtrim(str_replace('\','/', dirname($_SERVER['SCRIPT_NAME'])), '/');
$base = rtrim(preg_replace('#/admin$#','', $baseCurrent), '/');
if($base === '.') $base = '';
function url($path){ global $base; return ($base? $base : '') . '/' . ltrim($path,'/'); }
?>
<header>
  <div class="navbar">
    <div class="brand">Admin Panel</div>
    <nav>
      <a href="<?php echo url('admin/index.php'); ?>">Dashboard</a>
      <a href="<?php echo url('admin/banners.php'); ?>">Banner</a>
      <a href="<?php echo url('admin/narasumber.php'); ?>">Narasumber</a>
      <a href="<?php echo url('admin/peserta.php'); ?>">Peserta</a>
      <a href="<?php echo url('admin/artikel.php'); ?>">Artikel</a>
      <a href="<?php echo url('admin/registrations.php'); ?>">Registrasi</a>
      <a href="<?php echo url('admin/settings.php'); ?>">Pengaturan</a>
      <a href="<?php echo url('admin/profile.php'); ?>">Profil</a>
      <a href="<?php echo url('logout.php'); ?>">Logout</a>
    </nav>
  </div>
</header>
