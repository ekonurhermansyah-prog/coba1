<?php if(!function_exists('e')){ function e($s){return htmlspecialchars($s,ENT_QUOTES,'UTF-8');} }
$has_setting = function_exists('get_setting');
$f1t = $has_setting ? get_setting('footer_col1_title','Seminar & CFP') : 'Seminar & CFP';
$f1b = $has_setting ? get_setting('footer_col1_body','Diselenggarakan oleh Panitia Seminar.') : 'Diselenggarakan oleh Panitia Seminar.';
$f2t = $has_setting ? get_setting('footer_col2_title','Tautan') : 'Tautan';
$f2l = $has_setting ? get_setting('footer_col2_links','<ul><li><a href="/daftar.php">Daftar Seminar</a></li><li><a href="/upload.php">Unggah Artikel</a></li></ul>') : '<ul><li><a href="/daftar.php">Daftar Seminar</a></li><li><a href="/upload.php">Unggah Artikel</a></li></ul>';
$f3t = $has_setting ? get_setting('footer_col3_title','Ikuti Kami') : 'Ikuti Kami';
$f3b = $has_setting ? get_setting('footer_col3_body','<a href="#">Instagram</a> · <a href="#">YouTube</a>') : '<a href="#">Instagram</a> · <a href="#">YouTube</a>';
?>
<footer>
  <div class="footer-inner">
    <div>
      <h3><?php echo e($f1t); ?></h3>
      <p><?php echo $f1b; ?></p>
    </div>
    <div>
      <h4><?php echo e($f2t); ?></h4>
      <?php echo $f2l; ?>
    </div>
    <div>
      <h4><?php echo e($f3t); ?></h4>
      <p><?php echo $f3b; ?></p>
    </div>
  </div>
  <div class="copy">© <?php echo date('Y'); ?> Seminar & CFP</div>
</footer>
