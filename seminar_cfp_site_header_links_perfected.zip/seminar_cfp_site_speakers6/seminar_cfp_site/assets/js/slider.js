// assets/js/slider.js
(function(){
  const slides = document.querySelectorAll('.slide');
  const dots = document.querySelectorAll('.dot');
  if(!slides.length) return;
  let i=0; const show=(n)=>{
    slides.forEach((s,idx)=>s.classList.toggle('active', idx===n));
    if(dots.length) dots.forEach((d,idx)=>d.classList.toggle('active', idx===n));
  };
  show(i);
  setInterval(()=>{ i=(i+1)%slides.length; show(i); }, 5000);
  dots.forEach((d,idx)=>d.addEventListener('click',()=>{i=idx;show(i);}));
})();
