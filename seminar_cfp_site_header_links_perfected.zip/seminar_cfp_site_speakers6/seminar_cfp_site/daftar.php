<?php require_once __DIR__.'/config.php'; require_login(); $user=current_user();
$info='';
if($_SERVER['REQUEST_METHOD']==='POST'){
  $ticket=$_POST['ticket_type']??'Reguler';
  $st=$pdo->prepare('INSERT INTO registrations(user_id,ticket_type,payment_status) VALUES (?,?,?)');
  $st->execute([$user['id'],$ticket,'unpaid']);
  $info='Pendaftaran seminar tersimpan. Status pembayaran: unpaid.';
}
?>
<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Daftar Seminar</title><link rel="stylesheet" href="assets/css/style.css"></head>
<body>
<header><div class="navbar"><div class="brand">Seminar & CFP</div>
<nav><a href="index.php">Beranda</a><?php if(is_admin()):?><a href="admin/">Dashboard Admin</a><?php endif;?><a href="logout.php">Logout</a></nav></div></header>
<div class="container">
<h2>Daftar Seminar</h2>
<?php if($info): ?><div class="card"><div class="p"><?php echo e($info); ?></div></div><?php endif; ?>
<form method="post">
  <label>Pilih Tipe Tiket</label>
  <select name="ticket_type">
    <option>Reguler</option>
    <option>Mahasiswa</option>
    <option>Pemakalah</option>
  </select>
  <button class="btn" type="submit">Simpan Pendaftaran</button>
</form>
</div></body></html>
