<?php require_once __DIR__.'/../config.php'; require_admin();
$err='';$ok='';
if($_SERVER['REQUEST_METHOD']==='POST'){
  if(isset($_POST['create'])){
    $title=trim($_POST['title']??''); $subtitle=trim($_POST['subtitle']??'');
    $imgPath='';
    if(isset($_FILES['image']) && $_FILES['image']['error']===UPLOAD_ERR_OK){
      $dir='../uploads/banners/'; if(!is_dir($dir)) mkdir($dir,0777,true);
      $name = time().'_'.preg_replace('/[^a-z0-9\._-]/i','_', $_FILES['image']['name']);
      $dest = $dir.$name;
      if(move_uploaded_file($_FILES['image']['tmp_name'],$dest)){
        $imgPath = 'uploads/banners/'.$name;
      }
    }
    $st=$pdo->prepare('INSERT INTO banners(title,subtitle,image_path,is_active,sort_order) VALUES (?,?,?,?,?)');
    $st->execute([$title,$subtitle,$imgPath?:'assets/sample_banner.jpg',1, (int)($_POST['sort_order']??0)]);
    $ok='Banner ditambahkan.';
  }
  if(isset($_POST['update'])){
    $id=(int)$_POST['id']; $title=trim($_POST['title']??''); $subtitle=trim($_POST['subtitle']??''); $active= isset($_POST['is_active'])?1:0; $sort=(int)($_POST['sort_order']??0);
    $imgSql=''; $params=[$title,$subtitle,$active,$sort,$id];
    if(isset($_FILES['image']) && $_FILES['image']['error']===UPLOAD_ERR_OK){
      $dir='../uploads/banners/'; if(!is_dir($dir)) mkdir($dir,0777,true);
      $name = time().'_'.preg_replace('/[^a-z0-9\._-]/i','_', $_FILES['image']['name']);
      $dest = $dir.$name; if(move_uploaded_file($_FILES['image']['tmp_name'],$dest)){
        $imgSql=', image_path=?'; $params=[$title,$subtitle,$active,$sort,'uploads/banners/'.$name,$id];
      }
    }
    $sql = 'UPDATE banners SET title=?, subtitle=?, is_active=?, sort_order=?' . $imgSql . ' WHERE id=?';
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $ok='Banner diperbarui.';
  }
}
if(isset($_GET['del'])){ $pdo->prepare('DELETE FROM banners WHERE id=?')->execute([(int)$_GET['del']]); $ok='Banner dihapus.'; }
$banners=$pdo->query('SELECT * FROM banners ORDER BY sort_order ASC, id DESC')->fetchAll();
?>
<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Kelola Banner</title><link rel="stylesheet" href="../assets/css/style.css"></head>
<body>
<header><div class="navbar"><div class="brand">Admin Panel</div><nav><a href="index.php">Dashboard</a><a href="profile.php">Profil</a><a href="../logout.php">Logout</a></nav></div></header>
<div class="container">
<h2>Banner Slider</h2>
<?php if($err): ?><div class="card"><div class="p" style="color:#c00"><?php echo e($err); ?></div></div><?php endif; ?>
<?php if($ok): ?><div class="card"><div class="p" style="color:#070"><?php echo e($ok); ?></div></div><?php endif; ?>

<div class="card"><div class="p">
<h3>Tambah Banner</h3>
<form method="post" enctype="multipart/form-data">
  <input type="hidden" name="create" value="1">
  <label>Judul</label><input name="title">
  <label>Subjudul</label><input name="subtitle">
  <label>Urutan</label><input type="number" name="sort_order" value="0">
  <label>Gambar</label><input type="file" name="image" accept="image/*">
  <button class="btn" type="submit">Tambah</button>
</form>
</div></div>

<h3>Daftar Banner</h3>
<table class="table">
  <tr><th>#</th><th>Preview</th><th>Judul</th><th>Aktif</th><th>Urutan</th><th>Aksi</th></tr>
  <?php foreach($banners as $b): ?>
  <tr>
    <td><?php echo e($b['id']); ?></td>
    <td><?php if($b['image_path']): ?><img src="../<?php echo e($b['image_path']); ?>" style="height:40px"><?php endif; ?></td>
    <td><?php echo e($b['title']); ?><br><small><?php echo e($b['subtitle']); ?></small></td>
    <td><?php echo ($b['is_active'] ?? $b['active'])? 'Ya':'Tidak'; ?></td>
    <td><?php echo e($b['sort_order']); ?></td>
    <td>
      <details>
        <summary>Edit</summary>
        <form method="post" enctype="multipart/form-data" style="margin-top:8px">
          <input type="hidden" name="update" value="1">
          <input type="hidden" name="id" value="<?php echo e($b['id']); ?>">
          <label>Judul</label><input name="title" value="<?php echo e($b['title']); ?>">
          <label>Subjudul</label><input name="subtitle" value="<?php echo e($b['subtitle']); ?>">
          <label>Aktif?</label><input type="checkbox" name="is_active" <?php echo ($b['is_active'] ?? $b['active'])?'checked':''; ?>>
          <label>Urutan</label><input type="number" name="sort_order" value="<?php echo e($b['sort_order']); ?>">
          <label>Gambar (opsional)</label><input type="file" name="image" accept="image/*">
          <button class="btn" type="submit">Simpan</button>
          <a class="btn" style="background:#dc3545" href="?del=<?php echo e($b['id']); ?>" onclick="return confirm('Hapus banner ini?')">Hapus</a>
        </form>
      </details>
    </td>
  </tr>
  <?php endforeach; ?>
</table>
</div></body></html>
