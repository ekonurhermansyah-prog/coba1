<?php require_once __DIR__.'/../config.php'; require_admin(); ?>
<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Dashboard Admin</title><link rel="stylesheet" href="../assets/css/style.css"></head>
<body>
<header><div class="navbar"><div class="brand">Admin Panel</div><nav><a href="../index.php">Beranda</a><a href="banners.php">Banner</a><a href="narasumber.php">Narasumber</a><a href="peserta.php">Peserta</a><a href="artikel.php">Artikel</a><a href="../logout.php">Logout</a><a href="profile.php">Profil</a><a href="../logout.php">Logout</a></nav></div></header>
<div class="container">
  <h2>Selamat datang, Admin</h2>
  <div class="grid3">
    <div class="card"><div class="p"><h3>Banner Slider</h3><p>Kelola gambar dan teks banner.</p><p><a class="btn" href="banners.php">Kelola</a></p></div></div>
    <div class="card"><div class="p"><h3>Narasumber</h3><p>Edit 3 kolom narasumber.</p><p><a class="btn" href="narasumber.php">Kelola</a></p></div></div>
    <div class="card"><div class="p"><h3>Artikel</h3><p>Lihat artikel yang diunggah peserta.</p><p><a class="btn" href="artikel.php">Lihat</a></p></div></div>
  <div class="card"><div class="p"><h3>Registrasi Peserta</h3><p>Lihat & ekspor pendaftar.</p><p><a class="btn" href="registrations.php">Buka</a></p></div></div>
  </div>
</div>
</body></html>
