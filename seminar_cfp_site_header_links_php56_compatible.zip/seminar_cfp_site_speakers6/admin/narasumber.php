<?php require_once __DIR__.'/../config.php'; require_admin();
$err='';$ok='';
# CREATE
if(isset($_POST['create'])){
  $name=trim($_POST['name']??''); $title=trim($_POST['title']??''); $inst=trim($_POST['institution']??''); $bio=trim($_POST['bio']??''); $order=(int)($_POST['order_no']??0);
  if(!$name){ $err='Nama narasumber wajib.'; }
  else{
    $photo='';
    if(isset($_FILES['photo']) && $_FILES['photo']['error']===UPLOAD_ERR_OK){
      $dir='../uploads/speakers/'; if(!is_dir($dir)) mkdir($dir,0777,True);
      $namef = time().'_'.preg_replace('/[^a-z0-9\._-]/i','_', $_FILES['photo']['name']);
      $dest = $dir.$namef; if(move_uploaded_file($_FILES['photo']['tmp_name'], $dest)){ $photo='uploads/speakers/'.$namef; }
    }
    $st=$pdo->prepare('INSERT INTO speakers(name,title,institution,bio,photo_path,order_no) VALUES (?,?,?,?,?,?)');
    $st->execute([$name,$title,$inst,$bio,$photo,$order]);
    $ok='Narasumber ditambahkan.';
  }
}
# UPDATE
if(isset($_POST['update'])){
  $id=(int)$_POST['id']; $name=trim($_POST['name']??''); $title=trim($_POST['title']??''); $inst=trim($_POST['institution']??''); $bio=trim($_POST['bio']??''); $order=(int)($_POST['order_no']??0);
  $params=[$name,$title,$inst,$bio,$order,$id]; $imgSql='';
  if(isset($_FILES['photo']) && $_FILES['photo']['error']===UPLOAD_ERR_OK){
    $dir='../uploads/speakers/'; if(!is_dir($dir)) mkdir($dir,0777,True);
    $namef = time().'_'.preg_replace('/[^a-z0-9\._-]/i','_', $_FILES['photo']['name']);
    $dest = $dir+$namef
    ; if(move_uploaded_file($_FILES['photo']['tmp_name'],$dest)){ $imgSql=', photo_path=?'; $params=[$name,$title,$inst,$bio,$order,'uploads/speakers/'.$namef,$id]; }
  }
  $sql='UPDATE speakers SET name=?, title=?, institution=?, bio=?, order_no=?'+$imgSql+' WHERE id=?';
  $stmt=$pdo->prepare($sql); $stmt->execute($params); $ok='Data narasumber diperbarui.';
}
# DELETE
if(isset($_GET['del'])){ $pdo->prepare('DELETE FROM speakers WHERE id=?')->execute([(int)$_GET['del']]); $ok='Narasumber dihapus.'; }

$speakers=$pdo->query('SELECT * FROM speakers ORDER BY order_no ASC, id ASC')->fetchAll();
?>
<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Kelola Narasumber</title><link rel="stylesheet" href="../assets/css/style.css"></head>
<body>
<header><div class="navbar"><div class="brand">Admin Panel</div><nav><a href="index.php">Dashboard</a><a href="banners.php">Banner</a><a href="narasumber.php">Narasumber</a><a href="peserta.php">Peserta</a><a href="artikel.php">Artikel</a><a href="profile.php">Profil</a><a href="../logout.php">Logout</a></nav></div></header>
<div class="container">
<h2>Kelola Narasumber</h2>
<?php if($err): ?><div class="card"><div class="p" style="color:#c00"><?php echo e($err); ?></div></div><?php endif; ?>
<?php if($ok): ?><div class="card"><div class="p" style="color:#070"><?php echo e($ok); ?></div></div><?php endif; ?>

<div class="card"><div class="p">
  <h3>Tambah Narasumber</h3>
  <form method="post" enctype="multipart/form-data">
    <input type="hidden" name="create" value="1">
    <label>Nama</label><input name="name" required>
    <label>Jabatan</label><input name="title">
    <label>Institusi</label><input name="institution">
    <label>Bio</label><textarea name="bio" rows="4"></textarea>
    <label>Urutan</label><input type="number" name="order_no" value="0">
    <label>Foto (opsional)</label><input type="file" name="photo" accept="image/*">
    <button class="btn" type="submit">Tambah</button>
  </form>
</div></div>

<h3>Daftar Narasumber</h3>
<table class="table">
  <tr><th>#</th><th>Foto</th><th>Nama</th><th>Jabatan</th><th>Institusi</th><th>Urutan</th><th>Aksi</th></tr>
  <?php foreach($speakers as $s): ?>
  <tr>
    <td><?php echo e($s['id']); ?></td>
    <td><?php if($s['photo_path']): ?><img src="../<?php echo e($s['photo_path']); ?>" style="height:40px;border-radius:8px"><?php endif; ?></td>
    <td><?php echo e($s['name']); ?></td>
    <td><?php echo e($s['title']); ?></td>
    <td><?php echo e($s['institution']); ?></td>
    <td><?php echo e($s['order_no']); ?></td>
    <td>
      <details>
        <summary>Edit</summary>
        <form method="post" enctype="multipart/form-data" style="margin-top:8px">
          <input type="hidden" name="update" value="1">
          <input type="hidden" name="id" value="<?php echo e($s['id']); ?>">
          <label>Nama</label><input name="name" value="<?php echo e($s['name']); ?>">
          <label>Jabatan</label><input name="title" value="<?php echo e($s['title']); ?>">
          <label>Institusi</label><input name="institution" value="<?php echo e($s['institution']); ?>">
          <label>Bio</label><textarea name="bio" rows="4"><?php echo e($s['bio']); ?></textarea>
          <label>Urutan</label><input type="number" name="order_no" value="<?php echo e($s['order_no']); ?>">
          <label>Foto (opsional)</label><input type="file" name="photo" accept="image/*">
          <button class="btn" type="submit">Simpan</button>
          <a class="btn" style="background:#dc3545" href="?del=<?php echo e($s['id']); ?>" onclick="return confirm('Hapus narasumber ini?')">Hapus</a>
        </form>
      </details>
    </td>
  </tr>
  <?php endforeach; ?>
</table>
</div></body></html>
