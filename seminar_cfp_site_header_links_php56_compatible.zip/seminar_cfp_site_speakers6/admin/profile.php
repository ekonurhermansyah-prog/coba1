<?php require_once __DIR__.'/../config.php'; require_admin(); $u=current_user();
$ok=''; $err='';
if($_SERVER['REQUEST_METHOD']==='POST'){
  $name = trim($_POST['name']??'');
  $email = trim($_POST['email']??'');
  $pass = $_POST['password']??''; $conf = $_POST['password_confirm']??'';
  if(!$name||!$email){ $err='Nama dan email wajib diisi.'; }
  else{
    // check unique email (except current)
    $st=$pdo->prepare('SELECT id FROM users WHERE email=? AND id<>?');
    $st->execute([$email, $u['id']]);
    if($st->fetch()){ $err='Email sudah digunakan pengguna lain.'; }
    else{
      if($pass||$conf){
        if(strlen($pass)<6){ $err='Password minimal 6 karakter.'; }
        elseif($pass!==$conf){ $err='Konfirmasi password tidak cocok.'; }
      }
      if(!$err){
        if($pass){
          $hash=password_hash($pass, PASSWORD_DEFAULT);
          $st=$pdo->prepare('UPDATE users SET name=?, email=?, password_hash=? WHERE id=?');
          $st->execute([$name,$email,$hash,$u['id']]);
        } else {
          $st=$pdo->prepare('UPDATE users SET name=?, email=? WHERE id=?');
          $st->execute([$name,$email,$u['id']]);
        }
        // refresh session
        $st=$pdo->prepare('SELECT * FROM users WHERE id=?'); $st->execute([$u['id']]);
        $_SESSION['user']=$st->fetch();
        $ok='Profil berhasil diperbarui.';
      }
    }
  }
}
?>
<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Profil Admin</title><link rel="stylesheet" href="../assets/css/style.css"></head>
<body>
<header><div class="navbar"><div class="brand">Admin Panel</div><nav><a href="index.php">Dashboard</a><a href="banners.php">Banner</a><a href="narasumber.php">Narasumber</a><a href="peserta.php">Peserta</a><a href="artikel.php">Artikel</a><a href="profile.php">Profil</a><a href="../logout.php">Logout</a></nav></div></header>
<div class="container">
  <h2>Edit Profil Admin</h2>
  <?php if($ok): ?><div class="card"><div class="p" style="color:#0a0"><?php echo e($ok); ?></div></div><?php endif; ?>
  <?php if($err): ?><div class="card"><div class="p" style="color:#c00"><?php echo e($err); ?></div></div><?php endif; ?>
  <form method="post" style="max-width:520px">
    <label>Nama</label>
    <input name="name" value="<?php echo e(current_user()['name']); ?>" required>
    <label>Email</label>
    <input type="email" name="email" value="<?php echo e(current_user()['email']); ?>" required>
    <div class="small">Kosongkan password bila tidak ingin mengubah.</div>
    <label>Password Baru</label>
    <input type="password" name="password" placeholder="(opsional)">
    <label>Konfirmasi Password</label>
    <input type="password" name="password_confirm" placeholder="(opsional)">
    <button class="btn" type="submit">Simpan Perubahan</button>
  </form>
</div>
</body></html>
