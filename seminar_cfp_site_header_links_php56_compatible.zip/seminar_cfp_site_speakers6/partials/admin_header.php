<?php require_once __DIR__.'/../config.php'; require_admin();
$script = isset($_SERVER['SCRIPT_NAME']) ? $_SERVER['SCRIPT_NAME'] : '';
$scriptDir = dirname($script);
$scriptDir = str_replace('\\','/', $scriptDir);
$base = rtrim(preg_replace('#/admin$#','', $scriptDir), '/');
if($base === '.' || $base === '/') $base = '';
function url($path){ global $base; $p = ltrim($path,'/'); return ($base? $base : '') . '/' . $p; }
?>
<header>
  <div class="navbar">
    <div class="brand">Admin Panel</div>
    <nav>
      <a href="<?php echo url('admin/index.php'); ?>">Dashboard</a>
      <a href="<?php echo url('admin/banners.php'); ?>">Banner</a>
      <a href="<?php echo url('admin/narasumber.php'); ?>">Narasumber</a>
      <a href="<?php echo url('admin/peserta.php'); ?>">Peserta</a>
      <a href="<?php echo url('admin/artikel.php'); ?>">Artikel</a>
      <a href="<?php echo url('admin/registrations.php'); ?>">Registrasi</a>
      <a href="<?php echo url('admin/settings.php'); ?>">Pengaturan</a>
      <a href="<?php echo url('admin/profile.php'); ?>">Profil</a>
      <a href="<?php echo url('logout.php'); ?>">Logout</a>
    </nav>
  </div>
</header>
