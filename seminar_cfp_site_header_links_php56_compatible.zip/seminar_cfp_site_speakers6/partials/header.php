<?php
if(!function_exists('is_logged_in')){ function is_logged_in(){ return !empty($_SESSION['user']); } }
if(!function_exists('is_admin')){ function is_admin(){ $role = (isset($_SESSION['user']) && isset($_SESSION['user']['role'])) ? $_SESSION['user']['role'] : ''; return $role==='admin'; } }
if(!function_exists('e')){ function e($s){return htmlspecialchars($s,ENT_QUOTES,'UTF-8');} }
$logo = function_exists('get_setting') ? get_setting('site_logo_path','') : '';
// Base path detection for subfolder deployments (e.g., /seminar_cfp_site)
$script = isset($_SERVER['SCRIPT_NAME']) ? $_SERVER['SCRIPT_NAME'] : '';
$scriptDir = dirname($script);
$base = rtrim(str_replace('\\','/', $scriptDir), '/');
if($base === '.' || $base === '/') $base = '';
function url($path){ global $base; $p = ltrim($path,'/'); return ($base? $base : '') . '/' . $p; }
?>
<header>
  <div class="navbar">
    <div class="brand">
      <?php if($logo): ?>
        <img src="<?php echo e($logo); ?>" alt="Logo" style="height:28px">
      <?php else: ?>
        Seminar & CFP
      <?php endif; ?>
    </div>
    <nav>
      <a href="<?php echo url('index.php'); ?>">Beranda</a>
      <a href="<?php echo url('daftar.php'); ?>">Daftar Seminar</a>
      <a href="https://callforpaper.unw.ac.id/index.php/ICOELH" target="_blank" rel="noopener">Unggah Artikel</a>
      <a href="<?php echo url('speakers.php'); ?>">Narasumber</a>
      <a href="https://docs.google.com/document/d/1I3gVI4TBMYBGt8yuXBdOQ8i2M_37tiIe/edit?rtpof=true&sd=true&tab=t.0" target="_blank" rel="noopener">Template Artikel</a>
      <?php if(is_logged_in()): ?>
        <?php if(is_admin()): ?><a href="<?php echo url('admin/'); ?>">Dashboard Admin</a><?php endif; ?>
        <a href="<?php echo url('logout.php'); ?>">Logout</a>
      <?php else: ?>
        <a class="btn" href="<?php echo url('login.php'); ?>">Login</a>
      <?php endif; ?>
    </nav>
  </div>
</header>
