<?php require_once __DIR__.'/../config.php'; require_admin();
if(isset($_POST['set_status'])){
  $id=(int)$_POST['id']; $st=$_POST['status']??'submitted';
  $pdo->prepare('UPDATE articles SET status=? WHERE id=?')->execute([$st,$id]);
}
$rows=$pdo->query('SELECT a.*, u.name AS author_name, u.email AS author_email FROM articles a LEFT JOIN users u ON u.id=a.user_id ORDER BY a.created_at DESC')->fetchAll();
?>
<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Artikel</title><link rel="stylesheet" href="../assets/css/style.css"></head>
<body>
<header><div class="navbar"><div class="brand">Admin Panel</div><nav><a href="index.php">Dashboard</a></nav></div></header>
<div class="container">
<h2>Artikel Dikirim</h2>
<table class="table">
<tr><th>ID</th><th>Judul</th><th>Penulis</th><th>Tanggal</th><th>Status</th><th>Berkas</th><th>Aksi</th></tr>
<?php foreach($rows as $r): ?>
<tr>
  <td><?php echo e($r['id']); ?></td>
  <td><?php echo e($r['title']); ?></td>
  <td><?php echo e($r['author_name']); ?><br><small><?php echo e($r['author_email']); ?></small></td>
  <td><?php echo e($r['created_at']); ?></td>
  <td><?php echo e($r['status']); ?></td>
  <td><a class="btn" href="../<?php echo e($r['file_path']); ?>" target="_blank">Unduh</a></td>
  <td>
    <form method="post" style="display:flex;gap:6px">
      <input type="hidden" name="id" value="<?php echo e($r['id']); ?>">
      <select name="status">
        <?php foreach(['submitted','under_review','accepted','rejected'] as $s): ?>
          <option value="<?php echo $s; ?>" <?php echo $r['status']===$s?'selected':''; ?>><?php echo $s; ?></option>
        <?php endforeach; ?>
      </select>
      <button class="btn" name="set_status">Simpan</button>
    </form>
  </td>
</tr>
<?php endforeach; ?>
</table>
</div></body></html>
