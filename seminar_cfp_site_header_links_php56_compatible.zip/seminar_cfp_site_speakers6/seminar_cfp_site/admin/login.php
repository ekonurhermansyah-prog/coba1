<?php require_once __DIR__.'/../config.php'; if(is_admin()) redirect('index.php');
$err='';
if($_SERVER['REQUEST_METHOD']==='POST'){
  $email=trim($_POST['email']??''); $pass=$_POST['password']??'';
  $st=$pdo->prepare('SELECT * FROM users WHERE email=? AND role="admin"'); $st->execute([$email]); $u=$st->fetch();
  if($u && password_verify($pass,$u['password_hash'])){ $_SESSION['user']=$u; redirect('index.php'); }
  else{ $err='Email/password admin salah.'; }
}
?>
<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Login Admin</title><link rel="stylesheet" href="../assets/css/style.css"></head>
<body>
<header><div class="navbar"><div class="brand">Admin Panel</div><nav><a href="../index.php">Beranda</a></nav></div></header>
<div class="container">
<h2>Login Admin</h2>
<?php if($err): ?><div class="card"><div class="p" style="color:#c00"><?php echo e($err); ?></div></div><?php endif; ?>
<form method="post">
  <button class="btn" type="submit">Masuk</button>
</form>
</div></body></html>
