<?php require_once __DIR__.'/../config.php'; require_admin();
$ok='';
if($_SERVER['REQUEST_METHOD']==='POST'){
  $id=(int)$_POST['id']; $name=trim($_POST['name']??''); $title=trim($_POST['title']??''); $inst=trim($_POST['institution']??''); $bio=trim($_POST['bio']??''); $order=(int)($_POST['order_no']??$id);
  $params=[$name,$title,$inst,$bio,$order,$id]; $sqlImg='';
  if(isset($_FILES['photo']) && $_FILES['photo']['error']===UPLOAD_ERR_OK){
    $dir='../uploads/speakers/'; if(!is_dir($dir)) mkdir($dir,0777,true);
    $namef = time().'_'.preg_replace('/[^a-z0-9\._-]/i','_', $_FILES['photo']['name']);
    $dest=$dir.$namef; if(move_uploaded_file($_FILES['photo']['tmp_name'],$dest)){
      $sqlImg=', photo_path=?'; $params=[$name,$title,$inst,$bio,$order,'uploads/speakers/'+$namef,$id];
    }
  }
  $sql = 'UPDATE speakers SET name=?, title=?, institution=?, bio=?, order_no=?' . $sqlImg . ' WHERE id=?';
  $stmt=$pdo->prepare($sql); $stmt->execute($params); $ok='Data narasumber disimpan.';
}
$speakers=$pdo->query('SELECT * FROM speakers ORDER BY order_no ASC, id ASC LIMIT 3')->fetchAll();
?>
<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Kelola Narasumber</title><link rel="stylesheet" href="../assets/css/style.css"></head>
<body>
<header><div class="navbar"><div class="brand">Admin Panel</div><nav><a href="index.php">Dashboard</a></nav></div></header>
<div class="container">
<h2>Edit 3 Kolom Narasumber</h2>
<?php if($ok): ?><div class="card"><div class="p" style="color:#070"><?php echo e($ok); ?></div></div><?php endif; ?>
<div class="grid3">
  <?php foreach($speakers as $s): ?>
  <div class="card"><div class="p">
    <h3><?php echo e($s['name']); ?></h3>
    <?php if($s['photo_path']): ?><img src="../<?php echo e($s['photo_path']); ?>" style="width:100%;height:160px;object-fit:cover;border-radius:8px" alt="foto"><?php endif; ?>
    <form method="post" enctype="multipart/form-data">
      <input type="hidden" name="id" value="<?php echo e($s['id']); ?>">
      <label>Nama</label><input name="name" value="<?php echo e($s['name']); ?>">
      <label>Jabatan</label><input name="title" value="<?php echo e($s['title']); ?>">
      <label>Institusi</label><input name="institution" value="<?php echo e($s['institution']); ?>">
      <label>Bio</label><textarea name="bio" rows="4"><?php echo e($s['bio']); ?></textarea>
      <label>Foto (opsional)</label><input type="file" name="photo" accept="image/*">
      <label>Urutan</label><input type="number" name="order_no" value="<?php echo e($s['order_no']); ?>">
      <button class="btn" type="submit">Simpan</button>
    </form>
  </div></div>
  <?php endforeach; ?>
</div>
</div></body></html>
