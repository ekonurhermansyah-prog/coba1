<?php require_once __DIR__.'/../config.php'; require_admin();
$peserta=$pdo->query("SELECT id,name,email,affiliation,created_at FROM users WHERE role='peserta' ORDER BY created_at DESC")->fetchAll();
?>
<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Peserta</title><link rel="stylesheet" href="../assets/css/style.css"></head>
<body>
<header><div class="navbar"><div class="brand">Admin Panel</div><nav><a href="index.php">Dashboard</a></nav></div></header>
<div class="container">
<h2>Daftar Peserta</h2>
<table class="table">
<tr><th>ID</th><th>Nama</th><th>Email</th><th>Afiliasi</th><th>Terdaftar</th></tr>
<?php foreach($peserta as $p): ?>
<tr><td><?php echo e($p['id']); ?></td><td><?php echo e($p['name']); ?></td><td><?php echo e($p['email']); ?></td><td><?php echo e($p['affiliation']); ?></td><td><?php echo e($p['created_at']); ?></td></tr>
<?php endforeach; ?>
</table>
</div></body></html>
